
% Facts
parent(john, mary).
parent(mary, alice).
parent(john, david).

% Rule
grandparent(X, Y) :-
    parent(X, Z),
    parent(Z, Y).
