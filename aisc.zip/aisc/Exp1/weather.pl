temperature(38).
rain(yes).
humidity(high).

carry_umbrella :-
    rain(yes).

heat_alert :-
    temperature(T),
    T > 35.

high_humidity :-
    humidity(high).